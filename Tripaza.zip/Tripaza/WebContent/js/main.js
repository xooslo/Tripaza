let mainText = document.querySelector(".visual-font");

window.addEventListener('scroll' ,function(){
    let value = window.scrollY;
    console.log("scrollY" , value);
    
    

   
});